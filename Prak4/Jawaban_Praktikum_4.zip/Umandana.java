public class Umandana {
    /**
     * Mengembalikan kata yang telah diubah menjadi bahasa Umandana
     * Huruf a menjadi "aiden"
     * Huruf i menjadi "ipri"
     * Huruf u menjadi "upru"
     * Huruf e menjadi "epre"
     * Huruf o menjadi "opro"
     * Huruf mati yang tidak diikuti huruf vokal menjadi huruf tersebut + "es"
     * Suku kata "ng" yang tidak diikuti huruf vokal menjadi "strengen"
     * Suku kata "ng" yang diikuti huruf vokal tetap menjadi "ng"
     * Suku kata "ny" yang diikuti huruf vokal tetap menjadi "ny"
     * Selain ketentuan di atas, huruf/karakter tidak diubah
     * *
     * 
     * @param words
     * @return kata yang telah diubah menjadi bahasa Umandana
     * 
     */
    public static String toUmandana(String words) {
        StringBuilder sb = new StringBuilder(words.replaceAll("a", "aiden"));
        StringBuilder sb2 = new StringBuilder(words.replaceAll("i", "ipri"));
        words = words.replaceAll("u", "upru");
        words = words.replaceAll("e", "epre");
        words = words.replaceAll("o", "opro");
        int len = words.length();
        int i = 0;
        while (i < len){
            sb = sb.charAt(i);
        }
        while (i < len-1){
            if(((words.charAt(i) != 'a') || (words.charAt(i) != 'i') || (words.charAt(i) != 'u') || (words.charAt(i) != 'e') || (words.charAt(i) != 'o')) && ((words.charAt(i+1) == 'a') || (words.charAt(i+1) == 'i') || (words.charAt(i+1) == 'u') || (words.charAt(i+1) == 'e') || (words.charAt(i+1) == 'o'))){
                words.replaceAll(words.substring(i, i+1), (words.substring(i, i+1) + "es"));
            }
            i++;
        }
        len = words.length();
        i = 0;
        while (i < len-2){
            if((words.charAt(i) == 'n') && (words.charAt(i+1) == 'g') && ((words.charAt(i+2) != 'a') || (words.charAt(i+2) != 'i') || (words.charAt(i+2) != 'u') || (words.charAt(i+2) != 'e') || (words.charAt(i+2) != 'o'))){
                words.replaceAll("ng", "strengen");
            }
            i++;
        }
        String baru = sb.toString();
        return baru;
    }

    /**
     * Mengembalikan kata Umandana ke bentuk normal
     * *
     * 
     * @param words kata dalam bahasa Umandana
     * @return kata telah diubah ke bentuk normal
     */
    public static String deUmandana(String words) {
        int len = words.length();
        int i = 0;
        while (i < len-2){
            if(((words.charAt(i) != 'a') || (words.charAt(i) != 'i') || (words.charAt(i) != 'u') || (words.charAt(i) != 'e') || (words.charAt(i) != 'o')) && (words.charAt(i+1) == 'e') && (words.charAt(i+2) == 's')){
                words.replaceAll(words.substring(i, i+2), (words.substring(i,i)));
            }
            i++;
        }

        words.replaceAll("strengen", "ng");
        words.replaceAll("aiden", "a");
        words.replaceAll("ipri", "i");
        words.replaceAll("upru", "u");
        words.replaceAll("epre", "e");
        words.replaceAll("opro", "o");

        return words;
    }

}