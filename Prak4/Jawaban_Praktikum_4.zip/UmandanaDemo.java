import java.util.Scanner;
import java.lang.System;

public class UmandanaDemo {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        String words = sc.next();
        
        String res = Umandana.toUmandana(words);
        
        System.out.println(res);
        sc.close();
    }
}
